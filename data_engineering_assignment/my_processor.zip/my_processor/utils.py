import re

# Exception Handling Requirement: Define a custom exception class
class InvalidMemberDataError(Exception):
    """Raised when member data fails formatting or regex validation rules."""
    pass

def validate_email(email: str) -> bool:
    """Validates email addresses using regular expressions."""
    # Updated pattern prevents consecutive dots after the @ symbol
    pattern = r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
    if not re.match(pattern, email.strip()):
        raise InvalidMemberDataError(f"Invalid email structure: '{email}'")
    return True

def validate_phone(phone: str) -> bool:
    """Validates 3-4 digit hyphenated phone configurations (e.g., 555-0101)."""
    pattern = r'^\d{3}-\d{4}$'
    if not re.match(pattern, phone.strip()):
        raise InvalidMemberDataError(f"Invalid phone structure: '{phone}'")
    return True
