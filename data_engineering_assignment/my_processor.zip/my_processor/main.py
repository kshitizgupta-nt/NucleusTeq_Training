from my_processor.core import process_member_data, filter_members_by_name

if __name__ == "__main__":
    # Updated input dictionary accurately triggering validation loops
    raw_members = [
        {"name": "Kshitiz", "email": "Kshitiz.Gupta@example.com", "phone": "555-0101"},
        {"name": "Garv", "email": "Garv@example.com", "phone": "555-0102"},
        {"name": "InvalidData", "email": "Keshav@...com", "phone": "555-0102"}
    ]

    print("--- Starting Processing Run ---")
    valid_members = process_member_data(raw_members)

    # Trigger functional lambda sorting logic matching your requirements
    filtered_output = filter_members_by_name(valid_members, "Kshitiz")
    
    print("\n--- Functional Lambda Filter Results (Names starting with 'Kshitiz') ---")
    for match in filtered_output:
        print(match)
