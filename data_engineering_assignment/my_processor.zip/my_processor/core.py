from my_processor.utils import validate_email, validate_phone, InvalidMemberDataError

class Member:
    def __init__(self, name: str, email: str, phone: str):
        """OOP Requirement: Initializes individual users using self references."""
        self.name = name.strip()
        self.email = email.strip()
        self.phone = phone.strip()

    @classmethod
    def from_dict(cls, data: dict):
        """Factory method to validate strings and handle missing keys securely."""
        name = data.get("name", "Unknown")
        email = data.get("email")
        phone = data.get("phone")

        # Handle any missing data fields cleanly with a ValueError
        if not email or not phone:
            raise ValueError("Missing critical email or phone properties.")

        # Execute regex helpers from utils (raises InvalidMemberDataError if wrong)
        validate_email(email)
        validate_phone(phone)

        return cls(name, email, phone)

    def __str__(self):
        """String format matching standard package demonstration prints."""
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"


def process_member_data(raw_data_list: list) -> list:
    """Coordinates batch conversion and tracks profile logs cleanly."""
    processed_members = []
    success_count = 0

    for item in raw_data_list:
        name = item.get("name", "Unknown")
        
        # Matches exact console output syntax format from assignment rules
        print(f"Processing member: {name}...", end="")
        
        try:
            member_instance = Member.from_dict(item)
            processed_members.append(member_instance)
            success_count += 1
            print(" Validation Successful.")
            
        except (InvalidMemberDataError, ValueError):
            print(f"\nError: Invalid email for member '{name}'. Skipping.")

    print(f"Summary: {success_count} members processed successfully.")
    return processed_members


# Functional Programming Requirement: Lambda function with filter()
def filter_members_by_name(member_list: list, search_string: str) -> list:
    """Uses a Lambda function with filter() to slice custom user parameters."""
    return list(filter(lambda m: m.name.startswith(search_string), member_list))
