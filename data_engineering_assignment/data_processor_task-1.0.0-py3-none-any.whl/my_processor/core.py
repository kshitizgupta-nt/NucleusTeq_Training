from my_processor.utils import validate_email, validate_phone, InvalidMemberDataError

# OOP Requirement: Define a class with __init__ and self references
class Member:
    def __init__(self, name: str, email: str, phone: str):
        self.name = name
        self.email = email
        self.phone = phone

    def __str__(self):
        return f"Member(Name: {self.name}, Email: {self.email}, Phone: {self.phone})"


def process_member_data(raw_data_list: list) -> list:
    """Processes lists of dictionaries into instantiated Member structures."""
    processed_members = []
    success_count = 0

    for item in raw_data_list:
        name = item.get("name", "Unknown")
        email = item.get("email")
        phone = item.get("phone")

        try:
            print(f"Processing member: {name}...", end="")
            
            # Check for structural errors or missing keys
            if not email or not phone:
                raise ValueError("Missing critical fields")

            # Execute validation helpers
            validate_email(email)
            validate_phone(phone)

            # Instantiation on verification success
            member_instance = Member(name, email, phone)
            processed_members.append(member_instance)
            success_count += 1
            print(" Validation Successful.")

        except (InvalidMemberDataError, ValueError) as err:
            print(f"\nError: Invalid email for member '{name}'. Skipping. ({err})")

    print(f"Summary: {success_count} members processed successfully.")
    return processed_members


# Test execution script context
if __name__ == "__main__":
    # Example Input (Hardcoded list of dictionaries)
    raw_members = [
        {"name": "John Doe", "email": "john.doe@example.com", "phone": "555-0101"},
        {"name": "Jane Smith", "email": "jane.smith@...com", "phone": "555-0102"},
        {"name": "InvalidData", "email": "broken-email", "phone": "123-45"}
    ]

    print("--- Starting Processing Run ---")
    valid_members = process_member_data(raw_members)

    # Functional Programming Requirement: Lambda with filter() or map()
    # Filters out only members whose names start with the string "John"
    filtered_output = list(filter(lambda m: m.name.startswith("John"), valid_members))
    
    print("\n--- Functional Lambda Filter Results (Names starting with 'John') ---")
    for match in filtered_output:
        print(match)
