import re

# Exception Handling Requirement: Define a custom exception class
class InvalidMemberDataError(Exception):
    """Raised when member data fails formatting or regex validation rules."""
    pass

def validate_email(email: str) -> bool:
    """Validates email addresses using regular expressions."""
    # Pattern accommodates standard letters, numbers, and multiple dots/sequences
    pattern = r'^[\w\.-]+@[\w\.-]+\.[\w\.]+$'
    if not re.match(pattern, email):
        raise InvalidMemberDataError(f"Invalid email structure: '{email}'")
    return True

def validate_phone(phone: str) -> bool:
    """Validates 3-4 digit hyphenated phone configurations (e.g., 555-0101)."""
    pattern = r'^\d{3}-\d{4}$'
    if not re.match(pattern, phone):
        raise InvalidMemberDataError(f"Invalid phone structure: '{phone}'")
    return True
